#!/bin/bash

echo "systemctl stop xrmd"
systemctl stop xrmd
