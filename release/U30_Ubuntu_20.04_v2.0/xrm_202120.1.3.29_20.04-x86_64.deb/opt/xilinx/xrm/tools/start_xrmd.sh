#!/bin/bash

echo "systemctl start xrmd"
systemctl start xrmd
